package com.claimswift.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.*;
import java.util.UUID;

@Service
public class FileStorageService {

    private final Path uploadDir;

    public FileStorageService(@Value("${file.upload-dir}") String uploadDir) {
        this.uploadDir = Paths.get(uploadDir).toAbsolutePath().normalize();
        try {
            Files.createDirectories(this.uploadDir);
        } catch (IOException e) {
            throw new RuntimeException("Could not create upload directory", e);
        }
    }

    // --------------------- SAVE FILE ------------------------
    public String storeFile(MultipartFile file) {
        if (file == null || file.isEmpty()) return null;

        String fileName = file.getOriginalFilename();
        if (fileName == null) fileName = "file";

        String extension = "";
        int idx = fileName.lastIndexOf(".");
        if (idx > 0) extension = fileName.substring(idx);

        String cleanName = fileName.substring(0, idx > 0 ? idx : fileName.length());
        String uniqueFile = cleanName + "-" + UUID.randomUUID() + extension;

        try {
            Path target = uploadDir.resolve(uniqueFile).normalize();
            Files.copy(file.getInputStream(), target, StandardCopyOption.REPLACE_EXISTING);
            return uniqueFile;
        } catch (IOException e) {
            throw new RuntimeException("Failed to store file");
        }
    }

    // --------------------- LOAD FILE ------------------------
    public Resource loadFile(String fileName) {
        try {
            Path filePath = uploadDir.resolve(fileName).normalize();
            Resource resource = new UrlResource(filePath.toUri());

            if (resource.exists()) return resource;
            else throw new RuntimeException("File not found: " + fileName);

        } catch (MalformedURLException e) {
            throw new RuntimeException("File not found: " + fileName);
        }
    }
}
