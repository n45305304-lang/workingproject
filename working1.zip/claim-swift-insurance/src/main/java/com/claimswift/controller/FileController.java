package com.claimswift.controller;

import com.claimswift.model.Claim;
import com.claimswift.service.ClaimService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;

@RestController
@RequestMapping("/api/files")
@CrossOrigin(origins = "*")
public class FileController {

    @Autowired
    private ClaimService claimService;

    private final Path uploadDirPath;

    @Autowired
    public FileController(@Value("${file.upload-dir}") String uploadDir) {
        this.uploadDirPath = Paths.get(uploadDir).toAbsolutePath().normalize();
    }

    @GetMapping("/image/{claimId}")
    public ResponseEntity<byte[]> getImage(@PathVariable Long claimId) {

        Claim claim = claimService.getClaimById(claimId);
        if (claim == null || claim.getImagePath() == null || claim.getImagePath().isBlank()) {
            return ResponseEntity.notFound().build();
        }

        try {
            Path filePath = uploadDirPath.resolve(claim.getImagePath()).normalize();

            // safety: ensure the resolved path is still inside the upload directory
            if (!filePath.startsWith(uploadDirPath) || !Files.exists(filePath) || !Files.isReadable(filePath)) {
                return ResponseEntity.notFound().build();
            }

            byte[] data = Files.readAllBytes(filePath);

            // try to probe content type; fallback to extension checks
            String probe = Files.probeContentType(filePath);
            MediaType mediaType = MediaType.APPLICATION_OCTET_STREAM;
            if (probe != null) {
                try {
                    mediaType = MediaType.parseMediaType(probe);
                } catch (Exception ignored) { }
            } else {
                String filename = claim.getImagePath().toLowerCase();
                if (filename.endsWith(".png")) mediaType = MediaType.IMAGE_PNG;
                else if (filename.endsWith(".jpg") || filename.endsWith(".jpeg")) mediaType = MediaType.IMAGE_JPEG;
            }

            return ResponseEntity.ok()
                    .contentType(mediaType)
                    .body(data);

        } catch (Exception e) {
            return ResponseEntity.internalServerError().build();
        }
    }

    @GetMapping("/pdf/{claimId}")
    public ResponseEntity<byte[]> getPdf(@PathVariable Long claimId) {

        Claim claim = claimService.getClaimById(claimId);
        if (claim == null || claim.getPdfPath() == null || claim.getPdfPath().isBlank()) {
            return ResponseEntity.notFound().build();
        }

        try {
            Path filePath = uploadDirPath.resolve(claim.getPdfPath()).normalize();

            if (!filePath.startsWith(uploadDirPath) || !Files.exists(filePath) || !Files.isReadable(filePath)) {
                return ResponseEntity.notFound().build();
            }

            byte[] data = Files.readAllBytes(filePath);

            return ResponseEntity.ok()
                    .contentType(MediaType.APPLICATION_PDF)
                    .header(HttpHeaders.CONTENT_DISPOSITION,
                            "inline; filename=\"" + filePath.getFileName().toString() + "\"")
                    .body(data);

        } catch (Exception e) {
            return ResponseEntity.internalServerError().build();
        }
    }
}