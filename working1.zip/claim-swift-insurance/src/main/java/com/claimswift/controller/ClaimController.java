package com.claimswift.controller;

import com.claimswift.dto.ClaimPartDTO;
import com.claimswift.model.Claim;
import com.claimswift.model.ClaimPart;
import com.claimswift.service.ClaimService;
import com.claimswift.service.FileStorageService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/claims")
@CrossOrigin(origins = "*")
public class ClaimController {

    @Autowired
    private ClaimService claimService;

    @Autowired
    private FileStorageService fileStorageService;

    // ------------------ CREATE CLAIM ------------------
    @PostMapping(value = "/create", consumes = { MediaType.MULTIPART_FORM_DATA_VALUE })
    public ResponseEntity<?> createClaim(
            @RequestParam("userId") Long userId,
            @RequestParam(value = "image", required = false) MultipartFile image,
            @RequestParam(value = "pdf", required = false) MultipartFile pdf
    ) {
        try {
            String imagePath = (image != null && !image.isEmpty()) ? fileStorageService.storeFile(image) : null;
            String pdfPath = (pdf != null && !pdf.isEmpty()) ? fileStorageService.storeFile(pdf) : null;

            Claim claim = claimService.createClaim(userId, imagePath, pdfPath);

            return ResponseEntity.status(HttpStatus.CREATED).body(Map.of(
                    "message", "Claim created successfully",
                    "claim", claim
            ));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "Failed to create claim", "details", e.getMessage()));
        }
    }

    // ------------------ GET FILE (IMAGE OR PDF) ------------------
    @GetMapping("/{claimId}/file/{type}")
    public ResponseEntity<?> getClaimFile(
            @PathVariable Long claimId,
            @PathVariable String type
    ) {
        Claim claim = claimService.getClaimById(claimId);

        if (claim == null)
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("error", "Claim not found"));

        String fileName = null;

        if (type.equalsIgnoreCase("image")) {
            fileName = claim.getImagePath();
        } else if (type.equalsIgnoreCase("pdf")) {
            fileName = claim.getPdfPath();
        } else {
            return ResponseEntity.badRequest().body(Map.of("error", "Invalid type. Use 'image' or 'pdf'"));
        }

        if (fileName == null)
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("error", "No file found for this claim"));

        Resource resource = fileStorageService.loadFile(fileName);

        String contentType = type.equalsIgnoreCase("pdf") ? "application/pdf" : "image/jpeg";

        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(contentType))
                .header(HttpHeaders.CONTENT_DISPOSITION, "inline; filename=" + fileName)
                .body(resource);
    }

    // ------------------ OTHER APIS ------------------

    @GetMapping("/all")
    public ResponseEntity<?> getAllClaims() {
        return ResponseEntity.ok(claimService.getAllClaims());
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<?> getClaimsByUser(@PathVariable Long userId) {
        return ResponseEntity.ok(claimService.getClaimsByUserId(userId));
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getClaimById(@PathVariable Long id) {
        Claim claim = claimService.getClaimById(id);
        return (claim != null) ? ResponseEntity.ok(claim) : ResponseEntity.notFound().build();
    }

    @PostMapping("/{id}/approve")
    public ResponseEntity<?> approveClaim(
            @PathVariable Long id,
            @RequestBody List<ClaimPartDTO> partDTOs) {

        List<ClaimPart> claimParts = partDTOs.stream()
                .map(dto -> new ClaimPart(dto.getPartName(), dto.getAmount()))
                .collect(Collectors.toList());

        Claim updatedClaim = claimService.approveClaim(id, claimParts);

        if (updatedClaim == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("error", "Claim not found"));
        }

        return ResponseEntity.ok(Map.of(
                "message", "Claim approved successfully",
                "claim", updatedClaim
        ));
    }

    @PostMapping("/{id}/disapprove")
    public ResponseEntity<?> disapproveClaim(@PathVariable Long id) {
        Claim claim = claimService.disapproveClaim(id);

        if (claim == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("error", "Claim not found"));
        }

        return ResponseEntity.ok(Map.of(
                "message", "Claim disapproved successfully",
                "claim", claim
        ));
    }
}
